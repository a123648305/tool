# IIInsomniaCtiyPicker
城市选择插件，数据和内置的sql文件一致；<br/>
具体使用见html文件以及注释部分；<br/>
具有回调事件，选择城市后触发。<br/>
![image](https://github.com/IIInsomnia/IIInsomniaCtiyPicker/raw/master/view.png)
